export interface AnnouncementBase {
  id: number
  title: string
  content: string
  date: string
}
  